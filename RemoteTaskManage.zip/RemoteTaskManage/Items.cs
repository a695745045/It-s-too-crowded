﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RemoteTaskManage
{
    class Items
    {
        public string id = null;
        public Items[] children = null;
    }
}
